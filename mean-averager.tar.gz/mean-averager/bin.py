# A simple program to get the mean/average of a list of numbers.

import sys

def main(args):
	total = 0
	for arg in args:
		total += int(arg)
	mean = total / len(args)
	print(mean)

if __name__ == "__main__":
	main(sys.argv[1:])